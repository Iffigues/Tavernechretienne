# Changelog

## 1.0.0 - 2023-07-21

- First release

## 1.0.0 - 2023-10-23

- Update phpBB 3.3.11
- Unminify CSS files